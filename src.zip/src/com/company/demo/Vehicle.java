package com.company.demo;

public class Vehicle {
    public void start() {
        System.out.println("Starting in the engine");
    }

    public void stop() {
        System.out.println("stopping in the engine");
    }

    public  void orderPart(String part){
        System.out.println("part being ordered from : "+ part);
    }
}

