package com.company.demo;

import com.company.demo.luxuryvehicles.Executive;
import com.company.demo.luxuryvehicles.PremiumCompact;
import com.company.demo.luxuryvehicles.luxurycompact;
import com.company.demo.marketsegments.Microcar;
import com.company.demo.marketsegments.Minicompact;
import com.company.demo.marketsegments.Subcompact;
import com.company.demo.performancecars.HyperCar;

public class Main {

    public static  void  main(String[] args){

        Executive executive = new Executive();
        executive.setCarType("executive");
        executive.getCarType(new String("executive"));

        luxurycompact luxurycompact = new luxurycompact();
        luxurycompact.setCarType("luxuryCompact");
        luxurycompact.getCarType("luxurycompact");

        PremiumCompact premiumCompact = new PremiumCompact();
        premiumCompact.setCarType("ACURA ILX");
        premiumCompact.getCarType(new String("premiumCompact"));


        Microcar microcar = new Microcar();
        microcar.getsegMentType("microcar");


        Minicompact minicompact = new Minicompact();
        minicompact.carDetails();
        minicompact.getsegMentType("minicompact");

        Subcompact subcompact = new Subcompact();
        subcompact.setCarModel("subCompact");
        subcompact.getsegMentType("subcompact");

        HyperCar hyperCar = new HyperCar();
        hyperCar.getCarHorsePower("hypercar");

        Car car = new Car();
        car.getnOfSeats("car");

        Car car1 = new Car();
        car1.getnOfSeats("car1");

        CarMake carMake = new CarMake();
        carMake.setColour("carMake");

        CarParts carParts = new CarParts();
        carParts.orderPart("brakes for carParts");

    }


    //output  below in comments

    /*luxuryvehicle called :executive
    luxuryvehicle called :luxurycompact
    luxuryvehicle called :premiumCompact
    segment type called :microcar
    segment type called :minicompact
    segment type called :subcompact
    Premium car called: hypercar
    car being called : car
    car being called : car1
    colour being called : carMake
    part being ordered from : brakes for carParts*/

}
