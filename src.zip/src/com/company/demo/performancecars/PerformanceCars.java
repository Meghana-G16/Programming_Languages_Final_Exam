package com.company.demo.performancecars;

public class PerformanceCars {

    String carType;

    public String getCarType(String perfCar) {
        System.out.println("Perf car being set :" +perfCar);
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getCarHorsePower(String Premium) {
        System.out.println("Premium car called: "+ Premium);
        return carHorsePower;
    }

    public void setCarHorsePower(String carHorsePower) {
        this.carHorsePower = carHorsePower;
    }

    String carHorsePower;
}
