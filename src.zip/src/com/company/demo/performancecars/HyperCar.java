package com.company.demo.performancecars;

public class HyperCar extends PerformanceCars{
}
