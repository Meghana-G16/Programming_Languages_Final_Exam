package com.company.demo;

public class CarMake extends  Car{
}
