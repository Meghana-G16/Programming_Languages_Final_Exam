package com.company.demo.marketsegments;

public class Minicompact  extends  MarketSegments{

    public  void carDetails(){

    }
}
