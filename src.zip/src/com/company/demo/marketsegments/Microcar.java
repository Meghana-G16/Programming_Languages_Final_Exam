package com.company.demo.marketsegments;

public class Microcar extends MarketSegments{

    public void carDetails(){

    }
}
