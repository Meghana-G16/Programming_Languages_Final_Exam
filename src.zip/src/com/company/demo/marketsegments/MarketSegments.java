package com.company.demo.marketsegments;

public class MarketSegments {
    String segMentType;

    String carModel;
    public String getCarModel(String marketSegemnt) {
        System.out.println("market segment called: "+ marketSegemnt);

        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public void setsegMentType(String segMentType){
        this.segMentType = segMentType;
    }

    public String getsegMentType(String segmenttype){
        System.out.println("segment type called :" +segmenttype);
        return segMentType;
    }
}
