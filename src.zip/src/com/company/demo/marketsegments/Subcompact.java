package com.company.demo.marketsegments;

public class Subcompact extends  MarketSegments{
}
