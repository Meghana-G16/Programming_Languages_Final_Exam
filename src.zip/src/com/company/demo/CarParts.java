package com.company.demo;

public class CarParts extends Vehicle{
}
