package com.company.demo;

public class Car extends Vehicle {
    int nOfSeats = 4;
    String colour;

    public void setColour(String colour){
        System.out.println("colour being called : " +colour);
          this.colour = colour;
    }

    public int getnOfSeats(String car) {
        System.out.println("car being called : " +car);
        return nOfSeats;
    }
}
