package com.company.demo.luxuryvehicles;

public class PremiumCompact extends  LuxuryVehicles{
}
