package com.company.demo.luxuryvehicles;

public class luxurycompact extends LuxuryVehicles {
}
