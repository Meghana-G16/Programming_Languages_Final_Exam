package com.company.demo.luxuryvehicles;

public class LuxuryVehicles {

    int cost;


    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public String getCarType(String car) {
        System.out.println("luxuryvehicle called :"+car);
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    String carType;
}
